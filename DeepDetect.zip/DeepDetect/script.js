
    document.addEventListener('DOMContentLoaded', function() {
        const signUpButton = document.getElementById('signUpButton');
        const signInButton = document.getElementById('signInButton');
        const signInForm = document.getElementById('signIn');
        const signUpForm = document.getElementById('signup');

        // Check if the buttons exist and add event listeners
        if (signUpButton && signInButton && signInForm && signUpForm) {
            signUpButton.addEventListener('click', function () {
                signInForm.style.display = "none";
                signUpForm.style.display = "block";
            });

            signInButton.addEventListener('click', function () {
                signUpForm.style.display = "none";
                signInForm.style.display = "block";
            });
        }
    });
    const emailIcon = document.getElementById('emailIcon');
    const emailModal = document.getElementById('emailModal');
    const closeModal = document.getElementById('closeModal');
    
    // Show the modal when the email icon is clicked
    emailIcon.addEventListener('click', function() {
        emailModal.classList.remove('hidden');
    });
    
    // Close the modal when the "Close" button is clicked
    closeModal.addEventListener('click', function() {
        emailModal.classList.add('hidden');
    });
    
    // Optionally, handle the form submission
    document.getElementById('emailForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const email = document.getElementById('emailInput').value;
        alert(`Email submitted: ${email}`);
        // You can handle the email submission here (e.g., send it to the server)
        emailModal.classList.add('hidden');
    });
    