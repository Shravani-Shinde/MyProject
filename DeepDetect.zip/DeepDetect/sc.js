// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, setDoc, doc } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCu47oGKLp3uusHQM05ZbVePmOdh4Ghs4k",
  authDomain: "login-6efd9.firebaseapp.com",
  projectId: "login-6efd9",
  storageBucket: "login-6efd9.appspot.com",
  messagingSenderId: "947279815359",
  appId: "1:947279815359:web:ecc4b4313cd9e97cabdc0a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
function showMessage(message, divId){
  var messageDiv=document.getElementById(divId);
  messageDiv.style.display="block";
  messageDiv.innerHTML=message;
  messageDiv.style.opacity=1;
  setTimeout(function(){
      messageDiv.style.opacity=0;
  },5000);
}
// Sign-up button
const signup = document.getElementById('signup-submit');
signup.addEventListener('click', (event) => {
  event.preventDefault();
  
  // Get form values
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;
  const username = document.getElementById('signup-username').value;

  // Initialize Firebase services
  const auth = getAuth();
  const db = getFirestore();

  // Create user with email and password
  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      const user = userCredential.user;

      // Prepare user data for Firestore
      const userData = {
        email: email,
        username: username
      };
      
      // Log user data to ensure it's correct
      console.log("User created, UID:", user.uid);
      console.log("User data to store:", userData);

      // Store user data in Firestore
      const docRef = doc(db, "users", user.uid);
      return setDoc(docRef, userData);
    })
    .then(() => {
      // Redirect to log.html after successfully storing user data
      alert("Account created. Redirecting...");
      window.location.href = "index1.html";
    })
    .catch((error) => {
      // Log and handle errors
      const errorCode = error.code;
      console.error("Error during sign-up:", error); // Log full error
      
      if (errorCode === 'auth/email-already-in-use') {
        alert("Email already exists!");
      } else {
        alert("Unable to create user. Please try again.");
      }
    });
});

//login
const signIn = document.getElementById('login-submit');
signIn.addEventListener('click', (event) => {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const auth = getAuth();

    signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            alert("Login is successful");
            const user = userCredential.user;
            localStorage.setItem('loggedInUserId', user.uid);
            window.location.href = 'index1.html';
        })
        .catch((error) => {
            const errorCode = error.code;
            if (errorCode === 'auth/wrong-password') {
                alert("Incorrect Password");
            } else if (errorCode === 'auth/user-not-found') {
                alert("Account does not exist");
            } else {
                alert("Login failed. Please try again.");
            }
        });
});
